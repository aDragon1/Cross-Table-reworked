package com.adragon.newcrosstable

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

     val fragment: FileChooserFragment = supportFragmentManager.findFragmentById(R.id.fragment_fileChooser) as FileChooserFragment
        fragment.editTextPath.text = "Выберите таблицу (.xls)"

        val button = findViewById<Button>(R.id.nextAct)

//TODO("1: Получить путь к табличке" +
//            "2: company = Бренд" +
//            "3: model =  Модель" +
//            "4: part = наименование" +
//            "5: По нажатию на кнопку (анлок, если 3 спиннера выбраны) - переход на новую активитики, с остальной инфой"
//)
    }
}